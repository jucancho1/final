
package co.chile.ciclo3.ciclo3;

import org.springframework.data.repository.CrudRepository;

public interface InterfaceBike extends CrudRepository<Bike, Integer> {

}
