
package co.chile.ciclo3.ciclo3;

import org.springframework.data.repository.CrudRepository;

public interface InterfaceCliente extends CrudRepository<Cliente, Integer> {

}
